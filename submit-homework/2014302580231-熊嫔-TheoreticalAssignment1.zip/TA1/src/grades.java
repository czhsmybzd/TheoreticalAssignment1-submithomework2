import java.util.ArrayList;


public class grades {
	private long id;
	private String project;
	private String choice;
	private double credit;
	private String teacher;
	private String school;
	private String kind;
	private int year;
	private String term;
	private int score;
	public grades(long id,String project,String choice,double credit,String teacher,String school,String kind,int year,String term,int score)
	{
		//super();
		this.id=id;
		this.project=project;
		this.choice=choice;
		this.credit=credit;
		this.teacher=teacher;
		this.school=school;
		this.kind=kind;
		this.year=year;
		this.term=term;
		this.score=score;
	}
	
	public long getId(){
		return  id;
	}
	public String getProject(){
		return project;
	}
	public String getChoice(){
		return choice;
	}
	public double getCredit(){
		return credit;
	}
	public String getTeacher(){
		return teacher;
	}
	public String getSchool(){
		return school;
	}
	public String getKind(){
		return kind;
	}
	
	public int getYear(){
		return year;
	}
	public String getTerm(){
		return term;
	}
	public int getScore(){
		return score;
	}
	
	public String toString(ArrayList<grades> a){
		String b =id+"\t"+project+"\t"+choice+"\t"+credit+"\t"+teacher+"\t"+school+"\t"+kind+"\t"+year+"\t"+term+"\t"+score+"\t";
		return b;
	}
}
