import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainOutPut {
public static void main(String[] args){
	File file = new File("TA2.txt");
	MainOutPut a = new MainOutPut();
	a.processScoreTable(file);
}

public void processScoreTable(File input){
	try {
	    File file = new File("TA1.txt");
	    ArrayList<grades> grade = read(file);
	    double averageScore = getAverageScore(grade);
	    double averageGpa = getAverageGpa(grade);
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(input,true));
		for(grades i:grade){
			bufferedWriter.write( + i.getId() +"\t"+  i.getProject() +"\t"+ i.getChoice() +"\t"+ 
		            i.getCredit() +"\t"+ i.getTeacher() +"\t"+ i.getSchool() +"\t"+ i.getKind() 
					+"\t"+ i.getYear() +"\t"+ i.getTerm() +"\t"+ i.getScore()+"\r\n");
		}
		bufferedWriter.write("��Ȩƽ������"+averageScore+"�ۺϼ�ȨGPA��"+averageGpa);
		bufferedWriter.close();
		System.out.println(file);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
}

public static ArrayList<grades> read(File Input){
	ArrayList<grades> scores = new ArrayList<grades>();
	try{	
	InputStreamReader read = new InputStreamReader(new FileInputStream(Input),"gb2312");
	BufferedReader bufferedReader = new BufferedReader(read);  
    String lineTxt = null;  
    while((lineTxt = bufferedReader.readLine()) != null){  
        System.out.println(lineTxt); 
    	String row[] = lineTxt.split("\t");
    	//grades a1 = new grades(Long.parseLong(row[0]),row[1],row[2],Double.parseDouble(row[3]),row[4],row[5],row[6],Integer.parseInt(row[7]),row[8],Integer.parseInt(row[9]));
        //scores.add(a1);
    	scores.add(new grades(Long.parseLong(row[0]),row[1],row[2],Double.parseDouble(row[3]),row[4],row[5],row[6],Integer.parseInt(row[7]),row[8],Integer.parseInt(row[9])));
    }
        
	/*for(int i=0;lineTxt!= null;i++)
	{for(int j=0;j<10;j++){,
		row[i][j]=
	}
	}*/
    bufferedReader.close(); 
    SortByScore a = new SortByScore();
    Collections.sort(scores,a);
	
	}

	catch (Exception e) { 
    e.printStackTrace();  
}
	return scores;  
	
}
public static double getAverageScore(ArrayList<grades> a){
	double averageScore;
	double sumCredit = 0;
	double sumScore = 0;
	for(grades i:a){
		double credit = i.getCredit();
		double score = i.getScore();
		sumCredit += credit;
		sumScore += score*credit;
	}
	averageScore = sumScore/sumCredit;
	return averageScore;
}

public static double getAverageGpa(ArrayList<grades> a){
	double sumGpa = 0;
	double sumCredit = 0;
	double AverageGpa;
	for(grades i:a){
		double credit = i.getCredit();
		double score = i.getScore();
		double gpa = 0;
		if(score >= 90&&score <= 100) gpa = 4.0;
		else if(score >= 85&&score <= 89) gpa = 3.7;
		else if(score >= 82&&score <= 84) gpa = 3.3;
		else if(score >= 78&&score <= 81) gpa = 3.0;
		else if(score >= 75&&score <= 77) gpa = 2.7;
		else if(score >= 72&&score <= 74) gpa = 2.3;
		else if(score >= 68&&score <= 71) gpa = 2.0;
		else if(score >= 64&&score <= 67) gpa = 1.5;
		else if(score >= 80&&score <= 63) gpa = 1.0;
		else if(score < 60) gpa = 0;
		sumGpa += gpa * credit;
		sumCredit += credit;
	}
	AverageGpa = sumGpa/sumCredit;
	return AverageGpa;
}

}
class SortByScore implements Comparator<grades>{
	public int compare(grades a1,grades a2){
		grades grd1 = (grades)a1;
		grades grd2 = (grades)a2;
		if(grd1.getScore()<grd2.getScore()) return 1;
		else if(grd1.getScore()>grd2.getScore()) return -1;
		return 0;
			
	}

    public SortByScore(){
    	super();
    }
}

